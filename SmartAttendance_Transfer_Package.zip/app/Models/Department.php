<?php

namespace App\Models;

use PDO;

class Department extends Model {
    public static function all(): array {
        $stmt = self::db()->query("SELECT d.*, COUNT(e.id) as employee_count FROM departments d LEFT JOIN employees e ON d.id = e.department_id GROUP BY d.id ORDER BY d.name ASC");
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array {
        $stmt = self::db()->prepare("SELECT * FROM departments WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public static function create(string $name, ?string $code = null, ?string $description = null, ?string $headName = null, ?string $headEmail = null): int {
        $stmt = self::db()->prepare("INSERT INTO departments (name, code, description, head_name, head_email) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $code, $description, $headName, $headEmail]);
        return (int) self::db()->lastInsertId();
    }

    public static function update(int $id, string $name, ?string $code = null, ?string $description = null, ?string $headName = null, ?string $headEmail = null): bool {
        $stmt = self::db()->prepare("UPDATE departments SET name = ?, code = ?, description = ?, head_name = ?, head_email = ? WHERE id = ?");
        return $stmt->execute([$name, $code, $description, $headName, $headEmail, $id]);
    }

    public static function updateHead(int $id, string $headName, string $headEmail = ''): bool {
        $stmt = self::db()->prepare("UPDATE departments SET head_name = ?, head_email = ? WHERE id = ?");
        return $stmt->execute([$headName, $headEmail, $id]);
    }

    public static function delete(int $id): bool {
        $stmt = self::db()->prepare("DELETE FROM departments WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
